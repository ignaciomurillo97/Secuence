#include "naipe.h"
#include "controll.h"
extern Controll* game;

Naipe::Naipe(int valor, QString palo, QString Url)
{
    setPixmap(Url);
    this->valor = valor;
    this->palo = palo;

    setPos(50, 50);
    setAcceptHoverEvents(true);
    setFlag(QGraphicsItem::ItemIsFocusable);
}

void Naipe::hoverEnterEvent(QGraphicsSceneHoverEvent *event)
{
    setScale(60);   
}

void Naipe::hoverLeaveEvent(QGraphicsSceneHoverEvent *event)
{
    setScale(50);
}

void Naipe::mousePressEvent(QGraphicsSceneMouseEvent *event)
{
    qDebug()<<"ola k ase?";
    if (event->button() == Qt::LeftButton)
    {
        game->pickupCard(this);
        qDebug() << "Carta" << palo;
    }
}

void Naipe::setScale(float scale)
{
    setPixmap(this->pixmap().scaledToHeight(scale));
}

int Naipe::getValor() const
{
    return valor;
}


QString Naipe::getPalo() const
{
    return palo;
}


